#include <stdio.h>

enum e_enum
{
	c,
	s,
	p,
	u,
	x,
	X,
	d,
	i
};

int	main()
{
	printf("%c\n", 1);
}